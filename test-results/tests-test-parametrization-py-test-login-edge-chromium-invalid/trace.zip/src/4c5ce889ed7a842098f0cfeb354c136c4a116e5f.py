#https://demowebshop.tricentis.com/login

import pytest
from playwright.sync_api import Page,expect

creds = [("laura.taylor1234@example.com", "test123", "valid"),
    ("invaliduser@example.com", "test321", "invalid"),
    ("validuser@example.com", "testxyz", "invalid"),
    ("", "", "invalid")
        ]


@pytest.mark.parametrize("email, password, expected", creds)
def test_login(page: Page, email: str, password: str, expected: str):
    page.goto("https://demowebshop.tricentis.com/login")
    page.get_by_label("Email").fill(email)
    page.get_by_label("Password").fill(password)
    page.get_by_role("button", name="Log in").click()

    if expected == "valid":
        expect(page).to_have_url("https://demowebshop.tricentis.com/")
        expect(page.get_by_role("link", name="Log out")).to_be_visible()
    else:
        expect(page.locator(".validation-summary-errors")).to_be_visible()
